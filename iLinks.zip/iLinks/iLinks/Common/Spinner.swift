//
//  Spinner.swift
//  iLinks
//
//  Created by administrator on 4/8/18.
//  Copyright © 2018 administrator. All rights reserved.
//

import Foundation
import UIKit

class Spinner {
    
    static var view: UIView!
    static var activityIndicator: UIActivityIndicatorView!
    static var isAnimating = false
    
    class func configureSpinner(parentController: UIViewController, center: CGPoint, width: CGFloat = 200.0, height: CGFloat = 50.0)
    {
        let x = center.x - width/2.0
        let y = center.y - height/2.0
        
        //print(center)
        
        view = UIView(frame: CGRect(x: x, y: y, width: width, height: height))
        view.backgroundColor = UIColor.black
        view.layer.cornerRadius = 10
        
        activityIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        activityIndicator.color = UIColor.white
        activityIndicator.hidesWhenStopped = false
        
        let titleLabel = UILabel(frame: CGRect(x: 60, y: 0, width: 200, height: 50))
        titleLabel.text = TITLE_LOADING
        titleLabel.textColor = UIColor.white
        
        view.addSubview(self.activityIndicator)
        view.addSubview(titleLabel)
        
        parentController.view.addSubview(view)
        
        view.isHidden = true;
    }
    
    class func startAnimating()
    {
        if !isAnimating {
            isAnimating = true;
            
            DispatchQueue.main.async {
                view.isHidden = false;
                activityIndicator.startAnimating()
                UIApplication.shared.beginIgnoringInteractionEvents()
            }
            
        }
        
    }
    
    class func stopAnimating() {
        if isAnimating {
            isAnimating = false
            DispatchQueue.main.async {
                activityIndicator.stopAnimating()
                UIApplication.shared.endIgnoringInteractionEvents()
                view.isHidden = true;
            }
        }
    }
    
}
