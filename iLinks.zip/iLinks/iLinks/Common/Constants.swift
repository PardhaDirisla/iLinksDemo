//
//  Constants.swift
//  iLinks
//
//  Created by administrator on 4/8/18.
//  Copyright © 2018 administrator. All rights reserved.
//


let APP_TITLE    = "iLinks",

TITLE_MEDIA      = "Media Loader",

TITLE_WEATHER    = "Weather",

URL_NOT_EMPTY    = "URL should not be empty.",

ENTER_VALID_URL  = "Please enter a valid URL.",

TITLE_LOADING    = "Loading...",

NETWORK_ERROR    = "Net work error. Please check your internet connection.",

WEATHER_API      = "http://samples.openweathermap.org/data/2.5/weather?appid=b6907d289e10d714a6e88b30761fae22",

CITY_NOT_EMPTY   = "City Should not be empty.",

NO_RECORDS       = "No records found.";


