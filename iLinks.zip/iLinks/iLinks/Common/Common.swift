//
//  Common.swift
//  iLinks
//
//  Created by administrator on 4/8/18.
//  Copyright © 2018 administrator. All rights reserved.
//

import Foundation
import UIKit

func showAlert(message: String, viewController: UIViewController) {
    
    let alert = UIAlertController.init(title: APP_TITLE, message: message, preferredStyle: .alert)
    
    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
    
    viewController.present(alert, animated: true, completion: nil)
    
    alert.view.tintColor = UIColor.black;
    
}

func isURL(urlString:String?) -> Bool {
    
    if let urlStr = urlString, let url = URL(string:urlStr) {
        
        return UIApplication.shared.canOpenURL(url)
    }
    
    return false
}


