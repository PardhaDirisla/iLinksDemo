//
//  WeatherViewController.swift
//  iLinks
//
//  Created by administrator on 4/8/18.
//  Copyright © 2018 administrator. All rights reserved.
//

import UIKit

class WeatherViewController: UIViewController {

    
    @IBOutlet weak var cityField: UITextField!
    
    @IBOutlet weak var weatherDetailsTableview: UITableView!
    
    var weatherInfoArray = [[String:String]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Set Screen title
        self.title = TITLE_WEATHER
        weatherDetailsTableview.estimatedRowHeight = 70;
        weatherDetailsTableview.rowHeight = UITableViewAutomaticDimension
        
        //Configure spinner
        Spinner.configureSpinner(parentController: self, center: view.center)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK - Functions
    func loadWeatherReportFor(city:String) {
        
        //Preapre url string
        let urlString = "\(WEATHER_API)&q=\(city)"
        debugPrint(urlString)
        
        // Create URL
        let url = URL(string: urlString)!
        
        //Send request
        let task = URLSession.shared.dataTask(with: url) { [unowned self]
            (data, response, error)  in
            
            //Stop spinner
            Spinner.stopAnimating()
            
            // Check for error
            if error != nil
            {
                showAlert(message: (error?.localizedDescription)!, viewController: self)
            }
            else if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    
                    
                    do {
                        
                        //Check data
                        if let weatherData = try JSONSerialization.jsonObject(with: data!, options: []) as? [String:Any] {
                            
                            self.showWeatherDetails(weatherInfo: weatherData)
                            DispatchQueue.main.async {
                                self.weatherDetailsTableview.reloadData()
                            }
                        }
                        else {
                            showAlert(message: NO_RECORDS, viewController: self)
                        }
                        
                    } catch {
                        //debugPrint(error)
                    }
                    
                }
            }
            
        }
        
        task.resume()
    }
    
    func showWeatherDetails(weatherInfo:[String : Any]) {
        
        //Weather
        if let weather = weatherInfo["weather"] as? [[String:Any]?] {
            
            if let weatherInfo = weather[0] {
                
                var weatherStr = ""
                
                //main
                if let main = weatherInfo["main"] as? String {
                    weatherStr += main
                }
                //description
                if let desc = weatherInfo["description"] as? String {
                    weatherStr += "\n \(desc)"
                }
                
                weatherInfoArray.append(["Wind" : weatherStr])
            }
        }
        
        
        //Main info
        if let main = weatherInfo["main"] as? [String:Any] {
            //Temperature
            if let temp = main["temp"] as? Float {
                weatherInfoArray.append(["Temperature" : "\(temp)"])
            }
            
            //Min Temperature
            if let minTemp = main["temp_min"] as? Float {
                weatherInfoArray.append(["Min Temperature" : "\(minTemp)"])
            }
            
            //Max Temperature
            if let maxTemp = main["temp_max"] as? Float {
                weatherInfoArray.append(["Max Temperature" : "\(maxTemp)"])
            }
            
            //Pressure
            if let pressure = main["pressure"] as? Float {
                weatherInfoArray.append(["Pressure" : "\(pressure)"])
            }
            //Humidity
            if let humidity = main["humidity"] as? Float {
                weatherInfoArray.append(["Humidity" : "\(humidity)"])
            }
            
        }
        
        //Wind
        if let wind = weatherInfo["wind"] as? [String : Any] {
            
            if let speed = wind["speed"] as? Float {
                
                weatherInfoArray.append(["Wind Speed" : "\(speed)"])
            }
            if let degrees = wind["deg"] as? Float {
                
                weatherInfoArray.append(["Degrees" : "\(degrees)"])
            }
        }
        
    }

    // MARK: - IBActions
    @IBAction func onclickShowWeather(_ sender: Any) {
        
        if (Reachability.isConnectedToNetwork() == true)
        {
            //Load next page books
            
            if(cityField.text?.isEmpty)! {
                
                showAlert(message: CITY_NOT_EMPTY, viewController: self)
            }
            
            else {
                
                //Clear weather data
                weatherInfoArray = []
                DispatchQueue.main.async {
                    self.weatherDetailsTableview.reloadData()
                }
                
                
                //Start spinner
                Spinner.startAnimating()
                
                //Load details
                loadWeatherReportFor(city: cityField.text!)
                
                //resign url field
                cityField.resignFirstResponder()
            }
        }
        else {
            
            showAlert(message: NETWORK_ERROR, viewController: self)
        }
        
    }
}

extension WeatherViewController:UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherInfoArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "weatherCell", for: indexPath)
        
        let titleLabel   = cell.viewWithTag(1) as! UILabel
        let valueLabel   = cell.viewWithTag(2) as! UILabel
        
        let weatherDict  = weatherInfoArray[indexPath.row]
        for (key, value) in weatherDict {
            titleLabel.text = key
            valueLabel.text = value
        }
        
        return cell
        
    }
    
}
