//
//  MediaLoaderViewController.swift
//  iLinks
//
//  Created by administrator on 4/8/18.
//  Copyright © 2018 administrator. All rights reserved.
//

import UIKit

class MediaLoaderViewController: UIViewController {

    @IBOutlet weak var urlField: UITextField!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Set Screen title
        self.title = TITLE_MEDIA

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //show progress
        showProgress()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: - Private functions
    private func showProgress() {
        DownloadManager.shared.onProgress = { (progress) in
            OperationQueue.main.addOperation {
                self.progressView.progress = progress
            }
        }
    }
    
    //MARK: - IBActions
    @IBAction func onclickStartDownLoad(_ sender: Any) {
        
        if(DownloadManager.shared.isDownLoadFinished == true) {
            
            DownloadManager.shared.isDownLoadFinished = false
            
            if (Reachability.isConnectedToNetwork() == true)
            {
                //Load next page books
                
                if(urlField.text?.isEmpty)! {
                    
                    showAlert(message: URL_NOT_EMPTY, viewController: self)
                }
                else if(!isURL(urlString: urlField.text))  {
                    
                    showAlert(message: ENTER_VALID_URL, viewController: self)
                    
                }
                else {
                    //Load URL
                    let url = URL(string: urlField.text!)!
                    let task = DownloadManager.shared.activate().downloadTask(with: url)
                    task.resume()
                    
                    //resign url field
                    urlField.resignFirstResponder()
                }
            }
            else {
                
                showAlert(message: NETWORK_ERROR, viewController: self)
            }
        }
        
        
    }
  
    
//Class end
}
